package main

import (
	"web/gin_demo12bubby/dao"
	"web/gin_demo12bubby/model"
	"web/gin_demo12bubby/routers"
)

func main() {
	//创建数据库
	//sql: create database bubble;
	//连接数据库
	err := dao.InitMysql()
	if err != nil {
		panic(err)
	}
	defer dao.Close()
	//模型绑定
	dao.DB.AutoMigrate(&model.Todo{})

	r := routers.SetupRouter()
	r.Run()
}
