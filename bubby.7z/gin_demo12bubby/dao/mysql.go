package dao

import (
	"github.com/jinzhu/gorm"
	_ "github.com/go-sql-driver/mysql"

)

var (
	DB *gorm.DB
)

func InitMysql() (err error) {
	dsn := "root:tw926@tcp(127.0.0.1:3306)/bubble?charset=utf8mb4&parseTime=true&loc=Local"
	DB, err = gorm.Open("mysql", dsn)
	if err != nil {
		return
	}
	return DB.DB().Ping()
}

func Close()  {
	DB.Close()
}

